# CyberShield AI: Intelligent Scam and Phishing Detection

A student-built social-impact prototype that highlights common warning signs in suspicious messages and URLs and gives users practical digital-safety advice.

## Current implementation

This initial version uses transparent rule-based checks. It is **not yet a trained machine-learning model** and it cannot prove a message or URL is safe. Do not claim ML accuracy or production readiness until a labelled dataset, model, and evaluation have been implemented.

Features:
- Web form for message and URL checks
- Highlights common urgency, payment, impersonation, and URL-pattern signals
- Provides safety guidance
- Simple Flask application with no external API calls

## Requirements

- Python 3.10 or newer
- pip

## Setup

```bash
python -m venv .venv
```

Activate the environment:

- Windows PowerShell: `.venv\\Scripts\\Activate.ps1`
- macOS/Linux: `source .venv/bin/activate`

Install packages and run:

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000` in your browser.

## Project structure

```text
cybershield-ai/
├── app.py
├── detector.py
├── requirements.txt
├── README.md
├── LICENSE
├── data/
│   └── sample_cases.csv
├── docs/
│   └── architecture.md
├── tests/
│   └── test_detector.py
├── static/
│   └── style.css
└── templates/
    └── index.html
```

## Sample test inputs

1. Message: `Urgent: verify now or your account suspended. Send OTP immediately.`
   Expected: multiple warning indicators are shown.
2. Message: `Our club meeting starts at 3 PM in the library.`
   Expected: no configured indicators detected.
3. URL: `http://192.168.1.25/login`
   Expected: HTTP and IP-address warning indicators.
4. URL: `https://example.com`
   Expected: no common configured indicators. This does not mean a real URL is safe.

## Tests

```bash
python -m unittest discover -s tests -v
```

## Privacy and security

- Do not paste real passwords, OTPs, payment credentials, or confidential information.
- This app does not submit inputs to a third-party service.
- Do not deploy publicly with Flask debug mode enabled.
- Use HTTPS, input limits, secure deployment settings, and privacy review before public deployment.
- False positives and false negatives are possible.

## Roadmap

- Add a legally usable, documented labelled dataset.
- Train and evaluate a baseline text classifier.
- Add reproducible precision, recall, F1-score, and confusion-matrix reporting.
- Improve multilingual support and accessibility.
- Add user testing and privacy/security review.

## License

Released under the MIT License. See `LICENSE`.
